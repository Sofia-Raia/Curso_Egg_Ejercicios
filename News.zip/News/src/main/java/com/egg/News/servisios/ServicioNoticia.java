/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.egg.News.servisios;

import com.egg.News.entidades.Noticia;
import com.egg.News.excepciones.MiException;
import com.egg.News.repositorios.NoticiaRepositorio;
import com.egg.News.repositorios.NoticiaRepositorio;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author sofia
 */
@Service
public class ServicioNoticia {
//    Esta clase tiene la responsabilidad de llevar adelante las funcionalidades necesarias para
//    administrar noticias (consulta, creación, modificación y dar de baja).
    
    @Autowired
    private NoticiaRepositorio noticiaRepositorio;
     //////////////////////////////////consultar////////////////////////////////////////
    @Transactional(readOnly = true)
    public Noticia buscarPorId(String id){
        Optional<Noticia> respuesta = noticiaRepositorio.findById(id);
        if (respuesta.isPresent()){
            Noticia noticia = respuesta.get();
            if(noticia.isEstaActivo()) {
                return noticia;
            }
        }
        return null;
        
    }
     //////////////////////////////////crear////////////////////////////////////////////////
    @Transactional
    public void crearNoticia(String titulo,  String cuerpo) throws MiException {

        validar(titulo, cuerpo);
        Noticia noticia = new Noticia ();


        noticia.setTitulo(titulo);
        noticia.setCuerpo(cuerpo);
        noticia.setFechaAlta(new Date());
       
        noticiaRepositorio.save(noticia);
    }
    
    ////////////////////////////////////////////////modificar///////////////////////////////////////////////
    @Transactional
    public void modificarNoticia(String id, String titulo, String cuerpo) throws MiException {

        validar(id, titulo, cuerpo);

        Optional<Noticia> respuesta = noticiaRepositorio.findById(id); /// puede regresar sin datos

        if (respuesta.isPresent()) {

            Noticia noticia = respuesta.get();
            if (noticia.isEstaActivo()) {
                noticia.setTitulo(titulo);

                noticia.setCuerpo(cuerpo);
            
                noticiaRepositorio.save(noticia);
            }
        }
        
    }
    ///////////////////////////dar de baja?////////////////////////////////////////////
      @Transactional
    public void eliminar(String id) throws MiException{
        
        Optional<Noticia> respuesta = noticiaRepositorio.findById(id);
        if (respuesta.isPresent()) {
            Noticia noticia = respuesta.get();
            noticia.setEstaActivo(false);
            noticiaRepositorio.save(noticia);
        }
    }
/////////////////////////////////listar/////////////////////////////////////////////////////////
    @Transactional(readOnly = true)
    public List<Noticia> listarNoticia() {

        List<Noticia> noticias = new ArrayList();

        noticias = noticiaRepositorio.buscarActivas();//trae todas las noticias, incluso las que esta en "false"

        return noticias;
    }

///////////////////////////////////////validar ////////////////////////////////////////////////
    private void validar(String titulo, String cuerpo) throws MiException {

        if (titulo.isEmpty() || titulo == null) {
            throw new MiException("el titulo no puede ser nulo o estar vacio");
        }
      
        if (cuerpo.isEmpty() || cuerpo == null) {
            throw new MiException("el cuerpo no puede ser nulo o estar vacio");
        }

    }
    
    private void validar(String id, String titulo, String cuerpo) throws MiException {
        
        if(id == null){
            throw new MiException("el isbn no puede ser nulo"); //
        }

        if (titulo.isEmpty() || titulo == null) {
            throw new MiException("el titulo no puede ser nulo o estar vacio");
        }
      
        if (cuerpo.isEmpty() || cuerpo == null) {
            throw new MiException("el cuerpo no puede ser nulo o estar vacio");
        }

    }
 
    
    
//    RepositorioNoticia rn= new RepositorioNoticia();
//    Scanner leer = new Scanner(System.in).useDelimiter("\n");
//    public void crearNoticia() {
//
//        //persist() "CREAR" y guardar.
//        while (true) {
//            Noticia noticia = new Noticia ();
//            System.out.println("-Ingrese el título de la noticia que desea cargar:");
//            String titulo = leer.nextLine();
//            noticia.setTitulo(titulo);
//            System.out.println("-Ingrese el cuerpo de la noticia:");
//            String cuerpo = leer.nextLine();
//            noticia.setCuerpo(cuerpo);
//            
//            rn.crearNoticia(noticia);
//            
//            System.out.println("¿Desea ingresar otra noticia a la Base de Datos? Si/No");
//            String resp = leer.nextLine();
//
//            if (resp.equalsIgnoreCase("no")) {
//                break;
//            }
//
//        }
//    }
//        //find() "CONSULTA" busca y devuelve una entidad.
//
//    public void consultarNoticia(){
//
//        while(true){
//             System.out.println("Coloque el título de la noticia que desea buscar:");
//             String titulo=leer.nextLine();
//             Noticia noticia=rn.consultarNoticia(titulo);
//            if(noticia==null){
//                System.out.println("La noticia no existe, intente nuevamente. ");
//            }else{
//                System.out.println( "Información de la noticia: "+ noticia);
//                break;
//            }
//       
//        }
//    }
//        
//              //merge()sirve para actualizar
//    public void actualizarNoticia() {
//            Noticia noticia = new Noticia ();
//        while (true) {
//            System.out.println("Ingrese el título de la notica que quiere actualizar");
//            String titulo=leer.nextLine();
//            Noticia not= rn.consultarNoticia(titulo);
//            if (noticia== null){
//                System.out.println("La noticia no existe, intente nuevamente.");
//                break;
//            }
//            System.out.println("Ingrese el título de la notica que desea cargar:");
//            String nuevoTitulo = leer.nextLine();
//            not.setTitulo(nuevoTitulo);
//            System.out.println("Ingrese el cuerpo:");
//            String NuevoCuerpo=leer.nextLine();
//            not.setCuerpo(NuevoCuerpo);
//            rn.actualizarNoticia(noticia);
//             System.out.println("Se actualizo la noticia con EXITO!!!");
//            System.out.println("¿Desea actualizar otra noticia? si/no ");
//            String resppp=leer.nextLine();
//            if(resppp.equalsIgnoreCase("no")){
//                break;
//            }
//        }
//
//    }
//    
//        //remove()
//    public void eliminarNoticia(){
//        Noticia noticia= new Noticia();
//        while(true){
//            System.out.println("Ingrese el título de la notica que quiere eliminar");
//            String titulo=leer.nextLine();
//            Noticia not=rn.consultarNoticia(titulo);
//           
//            if(not==null){
//                System.out.println("La noticia no existe, intente nuevamente. ");
//                continue;
//            }
//            System.out.println( "Información de la noticia: "+ noticia);
//            //System.out.println("Esta seguro que desea eliminar la notica?");
//            not.setAlta(false);
//            rn.actualizarNoticia(not);
//            System.out.println("Informacion de la noticia eliminada:");
//            System.out.println(noticia);
//           
//            System.out.println("¿Desea eliminar otra noticia ? si/no");
//            String resp=leer.nextLine();
//            if(resp.equalsIgnoreCase("no")){
//                break;
//            }
//        }
//    }
    
}
