/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.egg.News.repositorios;

import com.egg.News.entidades.Noticia;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author sofia
 */
@Repository
public interface NoticiaRepositorio extends JpaRepository<Noticia, String>{
    @Query("SELECT n FROM Noticia n WHERE n.estaActivo = true")
    public List<Noticia> buscarActivas();
    
    @Query("SELECT l FROM Noticia l WHERE l.titulo = :titulo")
    public Noticia buscarPorTitulo(@Param("titulo") String titulo);
    
    @Query("SELECT l FROM Noticia l WHERE l.cuerpo = :cuerpo")
    public List<Noticia> buscarPorCuerpo(@Param ("cuerpo") String cuerpo); 
}

//    EntityManager em = Persistence.createEntityManagerFactory("libreria_jpaPU").createEntityManager();
//    Scanner leer = new Scanner(System.in).useDelimiter("\n");
//
//    public boolean crearNoticia(Noticia noticia) {
//        try {
//            em.getTransaction().begin();
//            em.persist(noticia);
//            em.getTransaction().commit();
//        } catch (Exception e) {
//            System.out.println("Error al intentar crear la noticia.");
//            e.printStackTrace();
//        }
//        return true;
//    }
//    //find() "CONSULTA" busca y devuelve una entidad.
//
//    public Noticia consultarNoticia(String titulo) {
//        Noticia noticia=null;
//        try {
//            noticia = (Noticia) em.createQuery("SELECT a FROM noticia a WHERE a.titulo LIKE :param1")
//                    .setParameter("param1", titulo)
//                    .getSingleResult();
//        } catch (Exception e) {
//            System.out.println("Fallo la consulta a la Base de Datos");
//            e.printStackTrace();
//        }
//            
//        return noticia;
//
//    }
//
//    //merge()sirve para actualizar
//    public void actualizarNoticia(Noticia noticia) {
//
//            em.getTransaction().begin();
//            em.merge(noticia);
//            em.getTransaction().commit();
//
//
//    }
//
//    //remove()
//      // no se usa porque no es una baja logica , estoy haciendo invisible los datos
//    public void eliminarNoticia(Noticia noticia){
//            em.getTransaction().begin();
//            em.remove(noticia);
//            em.getTransaction().commit();
//    }



